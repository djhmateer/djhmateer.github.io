#!/bin/bash

set -x
# a
#az group create -l westeurope -n TestRG2 kjkjk
# a

#AZURE_REGION="northeurope"
AZURE_REGION=$1
RESOURCEGROUP_NAME=$2 #TestRG-20190321_1631_172_refs_heads_master 
SERVICEPLAN_NAME="dotnetcoreb-asp"
# https://docs.microsoft.com/en-us/cli/azure/webapp?view=azure-cli-latest#az-webapp-create
#SERVICEPLAN_SKU="FREE"
SERVICEPLAN_SKU="D1" # this is Shared
WEBAPP_NAME=$3

echo "Azure Region is $AZURE_REGION" # westeurope
echo "RESOURCEGROUP_NAME is $RESOURCEGROUP_NAME" # TestRG-20190321_1631_172_refs_heads_master

az group create \
  --name $RESOURCEGROUP_NAME \
  --location $AZURE_REGION 

#az sql server create --name $SQL_SERVER_NAME --location $LOCATION --resource-group $RESOURCEGROUP_NAME 
#--admin-user $SQL_ADMIN_USERNAME --admin-password $SQL_ADMIN_PASSWORD

#az sql server firewall-rule create --resource-group $RESOURCEGROUP_NAME --server $SQL_SERVER_NAME -n AllowAllWindowsAzureIps 
#--start-ip-address 0.0.0.0 --end-ip-address 0.0.0.0

#az sql db create --resource-group $RESOURCEGROUP_NAME --server $SQL_SERVER_NAME --name $SQL_DATABASE_NAME --edition $SQL_EDITION 
#--collation $SQL_COLLATION --max-size $SQL_MAXSIZE --service-objective $SQL_SERVICEOBJECTIVE

# https://docs.microsoft.com/en-us/cli/azure/appservice/plan?view=azure-cli-latest
az appservice plan create \
    --name $SERVICEPLAN_NAME \
    --resource-group $RESOURCEGROUP_NAME \
    --sku $SERVICEPLAN_SKU

az webapp create \
    --name $WEBAPP_NAME \
    --resource-group $RESOURCEGROUP_NAME \
    --plan $SERVICEPLAN_NAME

#SQL_CONNECTIONSTRING="Data Source=tcp:'$(az sql server show -g $RESOURCEGROUP_NAME -n $SQL_SERVER_NAME --query fullyQualifiedDomainName -o tsv)'
#,1433;Initial Catalog='$SQL_DATABASE_NAME';User Id='$SQL_ADMIN_USERNAME';Password='$SQL_ADMIN_PASSWORD';"
#az webapp config connection-string set --resource-group $RESOURCEGROUP_NAME --name $WEBAPP_NAME --connection-string-type SQLServer 
#--settings DefaultConnection="$SQL_CONNECTIONSTRING"